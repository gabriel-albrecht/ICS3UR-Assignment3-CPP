// Copyright (c) 2019 St. Mother Teresa HS All rights reserved.
//
// Created by Gabriel A
// Created on Nov 2020
// This program calculates the cost of pizza
// A PS5 Controller costs 90 CAD

#include <iostream>
#include <iomanip>

int main() {
    // this function calculates the cost of pizza
    int units;
    int integer;
    double TOTAL;

    // input
    std::cout << "Desired amount of PS5 Controllers: ";
    std::cin >> units;

    integer = units * 90;

    if (units * 90 >= 1000) {
        integer = integer - (integer * 0.10);
    }

    // process
    TOTAL = integer * 1.13;

    // output
    std::cout << "" << std::endl;
    std::cout << "TOTAL FOR " << units << " PS5 CONTROLLERS IS: $"
    << std::fixed << std::setprecision(2) << std::setfill('0') << TOTAL <<
    "." << std::endl;
}
