# ICS3UR-Assignment3-CPP
ICS3UR Assignment3 CPP

A shop will give discount of 10% if the cost of purchased quantity is more than 1000. Ask user for quantity. 
Suppose, one unit will cost $100. Determine and print total cost for user, including HST.